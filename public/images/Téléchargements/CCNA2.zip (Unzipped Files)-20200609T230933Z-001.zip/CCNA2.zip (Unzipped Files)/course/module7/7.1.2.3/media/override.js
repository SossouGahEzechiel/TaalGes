override.pageType = "text-on-right"; // "text-on-left", "text-on-right", "full-media"
override.pageSize="470*400";